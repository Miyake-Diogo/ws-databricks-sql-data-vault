-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Business Data Vault [BDV]
-- MAGIC
-- MAGIC ### Point in Time [PIT]
-- MAGIC *Historical & Virtualized*
-- MAGIC * pit_users
-- MAGIC
-- MAGIC ### Bridge
-- MAGIC *Join Simplification*
-- MAGIC * bridge_users
-- MAGIC
-- MAGIC ### Reference
-- MAGIC *Static List*
-- MAGIC * ref_product_categories

-- COMMAND ----------

-- DBTITLE 1,pit_users
CREATE OR REFRESH LIVE TABLE pit_users
AS 
SELECT hb_users.hk_cpf AS hub_user_id,
       mssql_users.user_id AS mssql_sat_key,
       mongodb_users.user_id AS mongodb_sat_key,
       mssql_users.load_ts AS mssql_valid_from,
       mongodb_users.load_ts AS mongodb_valid_from,
       COALESCE(LEAD(mssql_users.load_ts) OVER (PARTITION BY hb_users.hk_cpf ORDER BY mssql_users.load_ts), '9999-12-31') AS mssql_valid_to,
       COALESCE(LEAD(mongodb_users.load_ts) OVER (PARTITION BY hb_users.hk_cpf ORDER BY mongodb_users.load_ts), '9999-12-31') AS mongodb_valid_to
FROM LIVE.hub_users AS hb_users
INNER JOIN LIVE.sat_mssql_user AS mssql_users
ON hb_users.hk_cpf = mssql_users.hk_cpf
INNER JOIN LIVE.sat_mongodb_user AS mongodb_users
ON hb_users.hk_cpf = mongodb_users.hk_cpf

-- COMMAND ----------

-- DBTITLE 1,bridge_users
CREATE OR REFRESH LIVE TABLE bridge_users
AS 
WITH bridge_users AS
(
  SELECT hb_users.hk_cpf AS hub_user_id,
          ROW_NUMBER() OVER(PARTITION BY hb_users.hk_cpf ORDER BY GREATEST(mssql_users.load_ts, mongodb_users.load_ts) DESC) AS rn_id,
          GREATEST(mssql_users.load_ts, mongodb_users.load_ts) AS valid_from,
          mssql_users.load_ts AS mssql_load_ts,
          mongodb_users.load_ts AS mongodb_load_ts,
          mssql_users.user_id AS mssql_user_id,
          mongodb_users.user_id AS mongodb_user_id,
          COALESCE(mssql_users.name, mongodb_users.name) AS name,
          COALESCE(mssql_users.date_birth, mongodb_users.date_birth) AS date_birth,
          COALESCE(mssql_users.phone_number, mongodb_users.phone_number) AS phone_number,
          COALESCE(mssql_users.city, mongodb_users.city) AS city,
          COALESCE(mssql_users.country, mongodb_users.country) AS country,
          COALESCE(mssql_users.source, mongodb_users.source) AS source
  FROM LIVE.hub_users AS hb_users
  LEFT OUTER JOIN LIVE.sat_mssql_user AS mssql_users
  ON hb_users.hk_cpf = mssql_users.hk_cpf
  LEFT OUTER JOIN LIVE.sat_mongodb_user AS mongodb_users
  ON hb_users.hk_cpf = mongodb_users.hk_cpf
)
SELECT *
FROM bridge_users
WHERE rn_id = 1

-- COMMAND ----------

-- DBTITLE 1,ref_product_categories
CREATE OR REFRESH LIVE TABLE ref_product_categories
AS 
SELECT DISTINCT product_id,
       CASE WHEN product_id = '8cf7e821-f0d3-49c6-8eba-e679c0ebcf6a' THEN 'UberX'
            WHEN product_id = '9a0e7b09-b92b-4c41-9779-2ad22b4d779d' THEN 'UberXL'
            WHEN product_id = '6c84fd89-3f11-4782-9b50-97c468b19529' THEN 'Uber Comfort'
            WHEN product_id = '997acbb5-e102-41e1-b155-9df7de0a73f2' THEN 'Uber Black'
            WHEN product_id = '6f72dfc5-27f1-42e8-84db-ccc7a75f6969' THEN 'Uber Green'
            WHEN product_id = '6d318bcc-22a3-4af6-bddd-b409bfce1546' THEN 'Scooters'
            WHEN product_id = '55c66225-fbe7-4fd5-9072-eab1ece5e23e' THEN 'Bikes'
            WHEN product_id = 'lyft' THEN 'LyftX'
            WHEN product_id = 'lyft_premier' THEN 'Lyft Premier'
            WHEN product_id = 'lyft_luxsuv' THEN 'Lyft Lux SUV'
            WHEN product_id = 'lyft_line' THEN 'Lyft Line'
            WHEN product_id = 'lyft_lux' THEN 'Lyft Lux'
            WHEN product_id = 'lyft_plus' THEN 'Lyft Plus'
       ELSE product_id END AS category
FROM LIVE.sat_mongodb_rides;