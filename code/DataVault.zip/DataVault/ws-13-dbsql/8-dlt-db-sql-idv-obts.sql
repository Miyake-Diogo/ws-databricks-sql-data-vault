-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Information Data Vault [IDV]
-- MAGIC
-- MAGIC ### One Big Tables [OBTs]
-- MAGIC * obt_agg_rides_per_product_category
-- MAGIC * obt_agg_rides_per_drive_type_desc
-- MAGIC * obt_list_cars_to_be_removed
-- MAGIC * obt_list_most_expensive_rides_per_country

-- COMMAND ----------

-- DBTITLE 1,obt_agg_rides_per_product_category
CREATE OR REFRESH LIVE TABLE obt_agg_rides_per_product_category
AS 
SELECT cat.category,
       SUM(rides.price_brl) AS total_brl,
       SUM(rides.distance_km) AS total_distance_km
FROM LIVE.sat_mongodb_rides AS rides
INNER JOIN LIVE.ref_product_categories AS cat
ON rides.product_id = cat.product_id
GROUP BY cat.category

-- COMMAND ----------

-- DBTITLE 1,obt_agg_rides_per_drive_type_desc
CREATE OR REFRESH LIVE TABLE obt_agg_rides_per_drive_type_desc
AS 
SELECT sat_vehicles.drive_type_desc,
       COUNT(rides.lnk_rides_id) AS count_rides
FROM LIVE.lnk_rides AS rides
INNER JOIN LIVE.hub_vehicles AS hub_vehicles
ON rides.hk_vehicle_id = hub_vehicles.hk_vehicle_id
INNER JOIN LIVE.sat_postgres_vehicle AS sat_vehicles
ON hub_vehicles.hk_vehicle_id = sat_vehicles.hk_vehicle_id
GROUP BY sat_vehicles.drive_type_desc

-- COMMAND ----------

-- DBTITLE 1,obt_list_cars_to_be_removed
CREATE OR REFRESH LIVE TABLE obt_list_cars_to_be_removed
AS 
SELECT sat_vehicles.*
FROM LIVE.hub_vehicles AS hub_vehicles
INNER JOIN LIVE.sat_postgres_vehicle AS sat_vehicles
ON hub_vehicles.hk_vehicle_id = sat_vehicles.hk_vehicle_id
WHERE car_classification = 'Old'

-- COMMAND ----------

-- DBTITLE 1,obt_list_most_expensive_rides_per_country
CREATE OR REFRESH LIVE TABLE obt_list_most_expensive_rides_per_country
AS 
SELECT users.country,
       ref_cat.category,
       SUM(sat_rides.distance_km) AS total_distance_km,
       SUM(sat_rides.price_brl) AS total_price_brl
FROM LIVE.bridge_users AS users
INNER JOIN LIVE.lnk_rides AS lnk_rides
ON users.hub_user_id = lnk_rides.hk_cpf
INNER JOIN LIVE.sat_mongodb_rides AS sat_rides
ON lnk_rides.lnk_rides_id = sat_rides.lnk_rides_id
INNER JOIN LIVE.ref_product_categories AS ref_cat
ON sat_rides.product_id = ref_cat.product_id
WHERE users.country IS NOT NULL
GROUP BY users.country, ref_cat.category