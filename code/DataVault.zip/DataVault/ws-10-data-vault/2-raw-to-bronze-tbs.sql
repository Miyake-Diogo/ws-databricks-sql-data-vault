-- Databricks notebook source
-- MAGIC %md
-- MAGIC
-- MAGIC # Landing Zone

-- COMMAND ----------

-- DBTITLE 1,bronze_mssql_user
CREATE OR REFRESH STREAMING TABLE bronze_mssql_user
AS SELECT * FROM STREAM read_files(
  'dbfs:/mnt/owshq-stg-files/com.owshq.data/mssql/users/', 
  format => 'json'
)

-- COMMAND ----------

-- DBTITLE 1,bronze_mongodb_user
CREATE OR REFRESH STREAMING TABLE bronze_mongodb_user
AS SELECT * FROM STREAM read_files(
  'dbfs:/mnt/owshq-stg-files/com.owshq.data/mongodb/users/', 
  format => 'json'
)

-- COMMAND ----------

-- DBTITLE 1,bronze_postgres_vehicle
CREATE OR REFRESH STREAMING TABLE bronze_postgres_vehicle
AS SELECT * FROM STREAM read_files(
  'dbfs:/mnt/owshq-stg-files/com.owshq.data/postgres/vehicle/', 
  format => 'json'
)

-- COMMAND ----------

-- DBTITLE 1,bronze_mongodb_rides
CREATE OR REFRESH STREAMING TABLE bronze_mongodb_rides
AS SELECT * FROM STREAM read_files(
  'dbfs:/mnt/owshq-stg-files/com.owshq.data/mongodb/rides/', 
  format => 'json'
)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Raw Vault

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Raw

-- COMMAND ----------

-- DBTITLE 1,raw_mssql_user_vw
CREATE STREAMING LIVE VIEW raw_mssql_user_vw
COMMENT "mssql user's raw dataset"
AS  
SELECT
  sha1(UPPER(TRIM(cpf))) as hk_hub_user_cpf,
  current_timestamp() as load_ts,
  "mssql" as source,
  cpf,
  user_id,
  uuid,
  first_name,
  last_name,
  date_birth,
  city,
  country, 
  company_name
FROM STREAM(LIVE.bronze_mssql_user)

-- COMMAND ----------

-- DBTITLE 1,raw_mongodb_user_vw
CREATE STREAMING LIVE VIEW raw_mongodb_user_vw
COMMENT "mongodb user's raw dataset"
AS  
SELECT
  sha1(UPPER(TRIM(cpf))) as hk_hub_user_cpf,
  current_timestamp() as load_ts,
  "mongodb" as source,
  cpf,
  user_id,
  first_name,
  last_name,
  date_of_birth,
  gender,
  social_insurance_number,
  email
FROM STREAM(LIVE.bronze_mongodb_user)

-- COMMAND ----------

-- DBTITLE 1,raw_postgres_vehicle_vw
CREATE STREAMING LIVE VIEW raw_postgres_vehicle_vw
COMMENT "postgres vehicle's raw dataset"
AS  
SELECT
  sha1(UPPER(TRIM(id))) as hk_hub_vehicle_id,
  current_timestamp() as load_ts,
  "postgres" as source,
  id,
  name,
  seats,
  km_driven,
  year
FROM STREAM(LIVE.bronze_postgres_vehicle)

-- COMMAND ----------

-- DBTITLE 1,raw_mongodb_rides_vw
CREATE STREAMING LIVE VIEW raw_mongodb_rides_vw
COMMENT "mongodb rides's raw dataset"
AS  
SELECT
  current_timestamp() as load_ts,
  "mongodb" as source,
  id,
  product_id,
  user_id,
  vehicle_id,
  cpf,
  name,
  source AS src_location,
  destination AS dst_location,
  distance,
  surge_multiplier,
  price,
  cab_type,
  time_stamp,  
  dt_current_timestamp  
FROM STREAM(LIVE.bronze_mongodb_rides)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Hubs

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE hub_user
(
  hk_hub_user_cpf STRING NOT NULL,
  cpf STRING NOT NULL,
  load_ts TIMESTAMP,
  source STRING
  CONSTRAINT valid_hk_hub_user_cpf EXPECT (hk_hub_user_cpf IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_cpf EXPECT (cpf IS NOT NULL) ON VIOLATION DROP ROW
)
COMMENT "user hub table"
AS 
SELECT DISTINCT
  hk_hub_user_cpf,
  cpf,
  load_ts,
  "mssql" AS source
FROM STREAM(live.raw_mssql_user_vw)
UNION ALL
SELECT DISTINCT
  hk_hub_user_cpf,
  cpf,
  load_ts,
  "mongodb" AS source
FROM STREAM(live.raw_mongodb_user_vw)

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE hub_vehicle
(
  hk_hub_vehicle_id STRING NOT NULL,
  id LONG NOT NULL,
  load_ts TIMESTAMP,
  source STRING
  CONSTRAINT valid_hk_hub_vehicle_id EXPECT (hk_hub_vehicle_id IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_id EXPECT (id IS NOT NULL) ON VIOLATION DROP ROW
)
COMMENT "vehicle hub table"
AS 
SELECT DISTINCT
  hk_hub_vehicle_id,
  id,
  load_ts,
  "postgres" AS source
FROM STREAM(live.raw_postgres_vehicle_vw)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Satellites

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE sat_mssql_user
(
  hk_hub_user_cpf STRING NOT NULL,
  user_id LONG,
  uuid STRING,
  first_name STRING,
  last_name STRING,
  date_birth STRING,
  city STRING,
  country STRING, 
  company_name STRING,
  load_ts TIMESTAMP,
  source STRING

  CONSTRAINT valid_hk_hub_user_cpf EXPECT (hk_hub_user_cpf IS NOT NULL) ON VIOLATION DROP ROW
)
COMMENT "mssql user's satellite table"
AS SELECT
  hk_hub_user_cpf,
  user_id,
  uuid,
  first_name,
  last_name,
  date_birth,
  city,
  country, 
  company_name,
  load_ts,
  source
FROM STREAM(live.raw_mssql_user_vw)

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE sat_mongodb_user
(
  hk_hub_user_cpf STRING NOT NULL,
  user_id LONG,
  first_name STRING,
  last_name STRING,
  date_of_birth STRING,
  gender STRING,
  social_insurance_number STRING,
  email STRING,
  load_ts TIMESTAMP,
  source STRING

  CONSTRAINT valid_hk_hub_user_cpf EXPECT (hk_hub_user_cpf IS NOT NULL) ON VIOLATION DROP ROW
)
COMMENT "mongodb user's satellite table"
AS SELECT
  hk_hub_user_cpf,
  user_id,
  first_name,
  last_name,
  date_of_birth,
  gender,
  social_insurance_number,
  email,
  load_ts,
  source
FROM STREAM(live.raw_mongodb_user_vw)

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE sat_postgres_vehicle
(
  hk_hub_vehicle_id STRING NOT NULL,
  id LONG,
  name STRING,
  seats DOUBLE,
  km_driven LONG,
  year LONG,
  load_ts TIMESTAMP,
  source STRING

  CONSTRAINT valid_hk_hub_vehicle_id EXPECT (hk_hub_vehicle_id IS NOT NULL) ON VIOLATION DROP ROW
)
COMMENT "postgres vehicle's satellite table"
AS SELECT
  hk_hub_vehicle_id,
  id,
  name,
  seats,
  km_driven,
  year,
  load_ts,
  source
FROM STREAM(live.raw_postgres_vehicle_vw)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Links

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE lnk_rides
(
  lnk_rides_id STRING NOT NULL,  
  hk_hub_user_cpf STRING NOT NULL, 
  hk_hub_vehicle_id STRING NOT NULL,
  id STRING,
  vehicle_id LONG,
  cpf STRING,
  load_ts TIMESTAMP  NOT NULL,
  source STRING NOT NULL
)
COMMENT "mongodb rides link table"
AS SELECT
  sha1(CONCAT(user.hk_hub_user_cpf, vehicle.hk_hub_vehicle_id)) as lnk_rides_id,
  user.hk_hub_user_cpf,
  vehicle.hk_hub_vehicle_id,
  rides.id,
  rides.vehicle_id,
  rides.cpf,
  current_timestamp AS load_ts,
  "mongodb" AS source
FROM STREAM(live.raw_mongodb_rides_vw) AS rides
INNER JOIN STREAM(live.hub_user) AS user
ON rides.cpf = user.cpf
INNER JOIN STREAM(live.hub_vehicle) AS vehicle
ON rides.vehicle_id = vehicle.id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Satellite

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE sat_mongodb_rides
(
  lnk_rides_id STRING NOT NULL,
  id STRING,
  product_id STRING,
  user_id LONG,
  vehicle_id LONG,
  cpf STRING,
  name STRING,
  src_location STRING,
  dst_location STRING,
  distance DOUBLE,
  surge_multiplier DOUBLE,
  price DOUBLE,
  cab_type STRING,
  time_stamp LONG,  
  dt_current_timestamp STRING,
  load_ts TIMESTAMP,
  source STRING

  CONSTRAINT valid_lnk_rides_id EXPECT (lnk_rides_id IS NOT NULL) ON VIOLATION DROP ROW
)
COMMENT "mongodb rides's satellite table"
AS SELECT
  lnk_rides.lnk_rides_id,
  rw_rides.id,
  rw_rides.product_id,
  rw_rides.user_id,
  rw_rides.vehicle_id,
  rw_rides.cpf,
  rw_rides.name,
  rw_rides.src_location,
  rw_rides.dst_location,
  rw_rides.distance,
  rw_rides.surge_multiplier,
  rw_rides.price,
  rw_rides.cab_type,
  rw_rides.time_stamp,  
  rw_rides.dt_current_timestamp,
  current_timestamp() as load_ts,
  "mongodb" as source  
FROM STREAM(live.raw_mongodb_rides_vw) AS rw_rides
INNER JOIN STREAM(live.lnk_rides) AS lnk_rides
ON rw_rides.id = lnk_rides.id
  AND rw_rides.vehicle_id = lnk_rides.vehicle_id
  AND rw_rides.cpf = lnk_rides.cpf

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Business Vault

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Point in Time {PIT}

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE pit_vehicles_tracking
COMMENT "pit table for tracking the vehicle load times"
AS  
SELECT
  hb_vehicle.hk_hub_vehicle_id, 
  hb_vehicle.id, 
  hb_vehicle.load_ts
FROM STREAM(LIVE.hub_vehicle) AS hb_vehicle
INNER JOIN STREAM(LIVE.sat_postgres_vehicle) AS st_vehicle
ON hb_vehicle.hk_hub_vehicle_id = st_vehicle.hk_hub_vehicle_id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Bridge Table{s}

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE bridge_rides_transaction
COMMENT "bridge table to track rides"
AS 
SELECT 
  user.cpf,
  vehicle.id AS vehicle_id
FROM STREAM (LIVE.raw_mongodb_rides_vw) AS rides
INNER JOIN STREAM (LIVE.hub_user) AS user
ON rides.cpf = user.cpf
INNER JOIN STREAM (LIVE.hub_vehicle) AS vehicle
ON rides.vehicle_id = vehicle.id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC ### Aggregate Table{s}

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE aggregate_rides_distance_price
COMMENT "aggregate table for rides"
AS 
SELECT cab_type, 
       SUM(distance) AS distance,
       SUM(price) AS price
FROM STREAM (LIVE.raw_mongodb_rides_vw) AS rides
GROUP BY cab_type

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # OBT {One Big Table}

-- COMMAND ----------

CREATE OR REFRESH STREAMING LIVE TABLE obt_rides_detailed
COMMENT "obt for all rides"
AS 
SELECT 
  hb_user.cpf, 
  st_mssql_user.first_name, 
  st_mssql_user.last_name, 
  st_mssql_user.city, 
  st_mssql_user.country, 
  st_mongodb_rides.name, 
  st_mongodb_rides.src_location, 
  st_mongodb_rides.dst_location, 
  st_mongodb_rides.distance, 
  st_mongodb_rides.surge_multiplier, 
  st_mongodb_rides.price, 
  st_mongodb_rides.cab_type,
  st_mongodb_rides.dt_current_timestamp
FROM STREAM (live.hub_user) AS hb_user
INNER JOIN STREAM (live.sat_mssql_user) AS st_mssql_user
ON hb_user.hk_hub_user_cpf = st_mssql_user.hk_hub_user_cpf
INNER JOIN STREAM (live.lnk_rides) AS lnk_rides
ON hb_user.hk_hub_user_cpf = lnk_rides.hk_hub_user_cpf
INNER JOIN STREAM (live.sat_mongodb_rides) AS st_mongodb_rides

-- COMMAND ----------

