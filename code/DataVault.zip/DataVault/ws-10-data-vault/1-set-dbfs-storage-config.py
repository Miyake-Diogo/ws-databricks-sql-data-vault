# Databricks notebook source
# DBTITLE 1,Mount Storage with dbfs
dbutils.fs.mount(
  source = "wasbs://owshq-stg-files@owshqblobstg.blob.core.windows.net",
  mount_point = "/mnt/owshq-stg-files",
  extra_configs = {"fs.azure.account.key.owshqblobstg.blob.core.windows.net":dbutils.secrets.get(scope = "az-blob-storage-owshqblobstg", key = "key-owshqblobstg")}
)

# COMMAND ----------

# DBTITLE 1,File Content
display(dbutils.fs.ls("/mnt/owshq-stg-files/"))
display(dbutils.fs.ls("/mnt/owshq-stg-files/com.owshq.data/"))

# COMMAND ----------

# DBTITLE 1,mssql.users
# MAGIC %sql
# MAGIC
# MAGIC select * 
# MAGIC from read_files('dbfs:/mnt/owshq-stg-files/com.owshq.data/mssql/users/2023_12_12_18_53_13.json', format => 'json') 
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,mongodb.users
# MAGIC %sql
# MAGIC
# MAGIC select * 
# MAGIC from read_files('dbfs:/mnt/owshq-stg-files/com.owshq.data/mongodb/users/2023_12_12_18_53_21.json', format => 'json') 
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,postgres.vehicle
# MAGIC %sql
# MAGIC
# MAGIC select * 
# MAGIC from read_files('dbfs:/mnt/owshq-stg-files/com.owshq.data/postgres/vehicle/2023_12_12_18_53_17.json', format => 'json') 
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,mongodb.rides
# MAGIC %sql
# MAGIC
# MAGIC select * 
# MAGIC from read_files('dbfs:/mnt/owshq-stg-files/com.owshq.data/mongodb/rides/2023_12_12_18_53_21.json', format => 'json') 
# MAGIC limit 10