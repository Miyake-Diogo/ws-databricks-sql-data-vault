-- Databricks notebook source
-- DBTITLE 1,Delete Pipeline Directory Folder
-- MAGIC %python
-- MAGIC
-- MAGIC display(dbutils.fs.rm("dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab", True))

-- COMMAND ----------

-- DBTITLE 1,Show Tables
-- MAGIC %python
-- MAGIC
-- MAGIC display(dbutils.fs.ls("dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab"))
-- MAGIC display(dbutils.fs.ls("dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables"))

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Hub

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_user`
-- SELECT cpf, COUNT(*) AS amount FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_user` GROUP BY cpf HAVING COUNT(*) > 1
-- SELECT hk_hub_user_cpf, COUNT(*) AS amount FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_user` GROUP BY hk_hub_user_cpf HAVING COUNT(*) > 1

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_vehicle`
-- SELECT id, COUNT(*) AS amount FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_vehicle` GROUP BY id HAVING COUNT(*) > 1
-- SELECT hk_hub_vehicle_id, COUNT(*) AS amount FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_vehicle` GROUP BY hk_hub_vehicle_id HAVING COUNT(*) > 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Satellite

-- COMMAND ----------

-- SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_mongodb_user/`
SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_mongodb_user/` WHERE hk_hub_user_cpf = '51daa081072b5c57fd945205beb5a6e1e94fa80b'
-- SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_user` WHERE hk_hub_user_cpf = '51daa081072b5c57fd945205beb5a6e1e94fa80b'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Links

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/lnk_rides`

-- COMMAND ----------

SELECT lnk_rides.id, lnk_rides.vehicle_id, lnk_rides.cpf, COUNT(*)
FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/bronze_mongodb_rides` AS rw_rides
INNER JOIN delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/lnk_rides` AS lnk_rides
ON rw_rides.id = lnk_rides.id
  AND rw_rides.vehicle_id = lnk_rides.vehicle_id
  AND rw_rides.cpf = lnk_rides.cpf
GROUP BY lnk_rides.id, lnk_rides.vehicle_id, lnk_rides.cpf
HAVING COUNT(*) > 1

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Review Tables {Data Vault}

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC display(dbutils.fs.ls("dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables"))

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_user`

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_mssql_user/`

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_mongodb_user/`

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_vehicle`

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_postgres_vehicle`

-- COMMAND ----------

SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_mongodb_rides`

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # PIT {Point in Time}

-- COMMAND ----------

-- SELECT * FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_vehicle/`

SELECT hb_vehicle.hk_hub_vehicle_id, hb_vehicle.id, hb_vehicle.load_ts FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_vehicle` AS hb_vehicle
INNER JOIN delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_postgres_vehicle/` AS st_vehicle
ON hb_vehicle.hk_hub_vehicle_id = st_vehicle.hk_hub_vehicle_id
WHERE hb_vehicle.hk_hub_vehicle_id = '1b6453892473a467d07372d45eb05abc2031647a'
ORDER BY hb_vehicle.id, st_vehicle.load_ts

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Bridge Table

-- COMMAND ----------

SELECT user.cpf,
       vehicle.id AS vehicle_id
FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/bronze_mongodb_rides` AS rides
INNER JOIN delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_user` AS user
ON rides.cpf = user.cpf
INNER JOIN delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_vehicle` AS vehicle
ON rides.vehicle_id = vehicle.id

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # Aggregate Table{s}

-- COMMAND ----------

SELECT cab_type, 
       SUM(distance) AS distance,
       SUM(price) AS price,
       current_timestamp() AS dt_timestamp
FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/bronze_mongodb_rides`
GROUP BY cab_type

-- COMMAND ----------

-- MAGIC %md
-- MAGIC
-- MAGIC # OBT {One Big Table}

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC display(dbutils.fs.ls("dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables"))

-- COMMAND ----------

CREATE TABLE obt_transactions_per_user_vehicle
AS
SELECT hb_user.cpf, 
  st_mssql_user.first_name, 
  st_mssql_user.last_name, 
  st_mssql_user.city, 
  st_mssql_user.country, 
  st_mongodb_rides.name, 
  st_mongodb_rides.src_location,
  st_mongodb_rides.dst_location, 
  st_mongodb_rides.distance, 
  st_mongodb_rides.surge_multiplier, 
  st_mongodb_rides.price, 
  st_mongodb_rides.cab_type, 
  st_mongodb_rides.dt_current_timestamp
FROM delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/hub_user/` AS hb_user
INNER JOIN delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_mssql_user/` AS st_mssql_user
ON hb_user.hk_hub_user_cpf = st_mssql_user.hk_hub_user_cpf
LEFT JOIN delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/lnk_rides/` AS lnk_rides
ON hb_user.hk_hub_user_cpf = lnk_rides.hk_hub_user_cpf
INNER JOIN delta.`dbfs:/pipelines/57ad4c4e-71cd-4b00-bdbe-6f9c13f1d0ab/tables/sat_mongodb_rides/` AS st_mongodb_rides
-- WHERE hb_user.cpf <> '955.451.029-22'

-- COMMAND ----------

SELECT *
FROM obt_transactions_per_user_vehicle
WHERE hb_user.cpf = '955.451.029-22'